import hashlib,json,sys,platform,importlib.metadata
from datetime import datetime,timezone
from pathlib import Path
r=Path(__file__).resolve().parents[2]
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
models=read(r/'configs/phase4_bev_v1.json')['models']
models['cuboid']={'path':'artifacts/runs/phase5-cuboid-v1-001/best.pt','sha256':'1ad8ccbf8e5409b476219b8ecaf0924922a756c19b845043b9cbeae99fd32f6f'}
for name,item in models.items():assert sha(r/item['path'])==item['sha256'];item['bytes']=(r/item['path']).stat().st_size
route_sources={n:sha(r/'artifacts/carla/PythonAPI/carla/agents/navigation'/n) for n in ['global_route_planner.py','local_planner.py','controller.py']}
write(r/'artifacts/reports/phase89-deployment-registry-final.json',{'status':'frozen_models_verified_no_training',
 'sampled_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),
 'packages':{n:importlib.metadata.version(n) for n in ['torch','torchvision','numpy','Pillow','carla']},'models':models,
 'CARLA_navigation_provider_sources':route_sources,'map_OpenDRIVE_sha256':read(r/'configs/phase89_routes_v1.json')['opendrive_sha256'],
 'live_inference':'local PyTorch CUDA; new eight RGB images each cycle','planner_controller':'classical map/ego-localization and RGB hybrid; not learned end-to-end',
 'map_and_ego_GT_prior_explicit':True,'other_actor_GT_in_planner':False,'new_training_runs':0,'packages_installed_this_turn':False,
 'offline_mode':'replay-only service imports neither Torch nor CARLA; NumPy/Pillow + copied recorded run PNG/JSON',
 'formal_model_quality_passed':False})
qa=r/'artifacts/runs/phase89-visual-QA-v1-001';catalog=read(qa/'catalog.json')
for item in catalog['cases']:assert sha(qa/item['file'])==item['plot_sha256']
write(qa/'assistant_review.json',{'status':'assistant_visually_reviewed_all_7_panels_and_2_contact_pages',
 'catalog_sha256':sha(qa/'catalog.json'),'original_catalog_status_preserved':catalog['status'],'cases':len(catalog['cases']),
 'basis':'Both complete contact sheets actually viewed; final desktop RGB/AI navigation screenshot inspected.',
 'observations':['All five final route cases stop within goal radius; map/GPS prior and actual ego trajectory are distinguished.',
  'Signal curve includes complete stationary red interval then resumption and turn; max route cross-track error .706m.',
  'Blocker001 remains stopped and is visibly incomplete; blocker002 resumes after removal, with stop-go jitter retained.',
  'Pedestrian case visibly reduces speed; last record .185m/s is within frozen .3m/s arrival threshold, not falsely reported exact zero.',
  'Controller/yield speed curves have intermittent braking and acceleration; comfort and dense traffic are not validated.',
  'Sensor validity fault stops before destination; failure-safe success is kept separate from arrival.',
  'Plots are evaluation-only map/ego localization priors, not RGB geometry accuracy; GT actor geometry not inserted into display.'],
 'formal_quality_passed':False,'files':{p.name:sha(p) for p in sorted(qa.glob('*.png'))}})
browser=r/'artifacts/reports/phase89-browser-001'
write(r/'artifacts/reports/phase89-UI-review-final.json',{'status':'assistant_visually_reviewed_and_source_checked',
 'final_desktop_sha256':sha(browser/'final-desktop.jpg'),'final_mobile_sha256':sha(browser/'final-mobile-390.jpg'),
 'observations':['Actual pedestrian at F121465 appears in source RGB; AI cuboid/trajectory and speed response visible in same frame.',
  'Clear badge distinguishes replay-only from live control; map route is explicitly a map prior.',
  'Manual stop and real WebGL context loss both ended worker and measured cleanup speed0 before destroying vehicle.',
  'Mobile390 has no horizontal overflow; eight camera switches loaded exact640x360 sources.',
  'Ctrl+Home while range was focused moved seek to0; final QA blurs range instead of treating that shortcut as page scroll.',
  'Revision/command ordering is a preventive async-state guard; shortcut focus is the directly observed cause of that QA seek reset.'],
 'numeric_receipt_comparison':{'first_exact_comparison_failed_at':'blocker F135136 path point1',
  'observed':1.0021819531638,'source':1.0021819531637999,'absolute_tolerance':1e-12,
  'maximum_observed_delta':read(r/'artifacts/reports/phase89-browser-verified-final.json')['maximum_JSON_numeric_absolute_delta'],
  'reason':'JSON/IEEE transport representation; structure/IDs/hashes/bools strict, original outputs unchanged'},
 'formal_quality_passed':False})
print({'models':len(models),'visual_panels':len(catalog['cases']),'status':'metadata_finalized'})
