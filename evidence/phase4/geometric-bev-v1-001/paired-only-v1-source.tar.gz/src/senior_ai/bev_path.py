"""Visible paired-lane center candidate; no map/GT route, no vehicle control."""
import numpy as np

def lane_center(bev,grid,config):
    xyz=grid.points();p=bev['probabilities'];line=(p[...,1]>=.25)&(p[...,0]>=.4)&bev['observed']
    points=[];bounds=[];previous=0.;previous_x=None
    for x in np.arange(config['x_min_m'],config['x_max_m']+.01,.5):
        yy=xyz[...,1][line&(np.abs(xyz[...,0]-x)<.3)]
        if len(yy)<4:continue
        ys=np.sort(yy);chunks=np.split(ys,np.where(np.diff(ys)>.25)[0]+1);centers=[float(np.median(c)) for c in chunks if len(c)>=2]
        pairs=[]
        for a in centers:
            for b in centers:
                if not config['minimum_width_m']<=b-a<=config['maximum_width_m']:continue
                mid=(a+b)/2
                if previous_x is None and not a<0<b:continue
                if previous_x is not None and (x-previous_x>3 or abs(mid-previous)>.5*(x-previous_x)+.2):continue
                pairs.append((abs(mid-previous),a,b))
        if not pairs:continue
        _,a,b=min(pairs);previous=(a+b)/2;previous_x=x;points.append([float(x),previous]);bounds.append([a,b])
    if len(points)<8 or points[-1][0]-points[0][0]<config['minimum_span_m']:
        return {'status':'unavailable','reason':'insufficient_paired_visible_lane_evidence','points_ego_m':[],'control_issued':False}
    points=np.asarray(points);coeff=np.polyfit(points[:,0],points[:,1],2);residual=float(np.sqrt(np.mean((np.polyval(coeff,points[:,0])-points[:,1])**2)))
    if residual>.35:return {'status':'unavailable','reason':'inconsistent_lane_pair','points_ego_m':[],'control_issued':False}
    samples=np.arange(points[0,0],points[-1,0]+.01,.5)
    return {'status':'candidate','source':'paired_predicted_lane_marks_ground_plane','points_ego_m':np.stack([samples,np.polyval(coeff,samples)],1).tolist(),
            'observed_pairs':len(points),'span_m':float(points[-1,0]-points[0,0]),'fit_rmse_m':residual,'median_width_m':float(np.median(np.diff(bounds,axis=1))),
            'control_issued':False,'limits':'Visible local center candidate; no destination routing, traffic rules or closed-loop proof'}
